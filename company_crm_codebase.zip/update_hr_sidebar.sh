#!/bin/bash

# Script to automatically update all HR department HTML files with universal sidebar

HR_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/hr/employees.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/recruitment.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/performance-reviews.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/settings.html"
)

echo "Updating HR department HTML files with universal sidebar..."

for file in "${HR_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "Processing: $file"
        
        # Add universal sidebar script if hr-utils.js exists
        if grep -q "hr-utils.js" "$file"; then
            # Check if universal-sidebar.js is already included
            if ! grep -q "universal-sidebar.js" "$file"; then
                sed -i 's|<script src="/static/js/hr-utils.js?v=3"></script>|<script src="/static/js/hr-utils.js?v=3"></script>\n    <script src="/static/js/universal-sidebar.js?v=1"></script>|g' "$file"
                echo "  - Added universal-sidebar.js script"
            fi
        fi
        
        echo "  - Updated: $file"
    else
        echo "  - File not found: $file"
    fi
done

echo "HR department files update completed!"
