#!/bin/bash

# Script to add universal sidebar initialization to Sales department files

SALES_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/sales/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leads.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/customers.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports_new.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/advanced_reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/payments.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/profile.html"
)

echo "Adding universal sidebar initialization to Sales department files..."

for file in "${SALES_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "Processing: $file"
        
        # Check if file already has loadCurrentUser or similar user loading function
        if grep -q "loadCurrentUser\|getCurrentUser" "$file"; then
            # Add initialization after user loading
            if ! grep -q "initializeUniversalSidebar\|universalSidebar.manualInit" "$file"; then
                # Look for loadCurrentUser and add initialization after it
                sed -i '/await loadCurrentUser();/a\\n            // Initialize universal sidebar\n            if (window.currentUser && window.universalSidebar) {\n                window.universalSidebar.manualInit(window.currentUser);\n            }' "$file"
                echo "  - Added universal sidebar initialization after loadCurrentUser"
            fi
        elif grep -q "DOMContentLoaded" "$file"; then
            # Add to DOMContentLoaded if no user loading function exists
            if ! grep -q "initializeUniversalSidebar\|universalSidebar.manualInit" "$file"; then
                # Add a generic initialization
                sed -i '/document.addEventListener.*DOMContentLoaded/,/});/{
                    /});/i\
\
            // Initialize universal sidebar with fallback\
            setTimeout(() => {\
                const token = localStorage.getItem("bhoomitechzone_token");\
                if (token && window.universalSidebar) {\
                    fetch("/users/me", {\
                        headers: { "Authorization": `Bearer ${token}` }\
                    })\
                    .then(response => response.json())\
                    .then(user => {\
                        if (user && !user.detail) {\
                            window.universalSidebar.manualInit(user);\
                        }\
                    })\
                    .catch(console.error);\
                }\
            }, 500);
                }' "$file"
                echo "  - Added universal sidebar initialization to DOMContentLoaded"
            fi
        else
            echo "  - Warning: No suitable initialization point found"
        fi
    else
        echo "  - File not found: $file"
    fi
done

echo ""
echo "Universal sidebar initialization added to Sales department files!"
