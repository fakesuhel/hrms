from fastapi import FastAPI
from app.utils.pdf_generator import generate_salary_slip_pdf
import asyncio

app = FastAPI()

test_data = {
    'employee_name': 'Test Employee',
    'employee_id': '12345',
    'month': 7,
    'year': 2024,
    'issue_date': '17-07-2024',
    'base_salary': 50000,
    'hra': 10000,
    'allowances': 5000,
    'department': 'IT',
    'designation': 'Developer',
    'absent_days': 1,
    'half_days': 0,
    'incentives': 2000,
    'pf_deduction': 6000,
    'tax_deduction': 2000,
    'penalty_deductions': 0,
    'other_deductions': 200
}

async def test():
    pdf = await generate_salary_slip_pdf(test_data)
    print(f'PDF generated successfully. Size: {len(pdf)} bytes')
    
    # Save the PDF to a file to verify it's working
    with open("test_salary_slip.pdf", "wb") as f:
        f.write(pdf)
    print("PDF saved to test_salary_slip.pdf")

if __name__ == "__main__":
    asyncio.run(test())
