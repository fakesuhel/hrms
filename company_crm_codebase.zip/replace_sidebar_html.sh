#!/bin/bash

# Script to replace static sidebar HTML with universal sidebar placeholder

echo "Replacing static sidebar HTML with universal sidebar placeholders..."

# Function to replace sidebar content in HTML files
replace_sidebar_html() {
    local file="$1"
    
    if [ ! -f "$file" ]; then
        echo "  - File not found: $file"
        return
    fi
    
    echo "  Processing: $file"
    
    # Use Python to perform complex HTML replacement
    python3 << EOF
import re

try:
    with open('$file', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Pattern to match sidebar content from <aside class="sidebar"> to </aside>
    # This handles nested HTML properly
    pattern = r'(<aside class="sidebar"[^>]*>).*?(<\/aside>)'
    replacement = r'\1\n            <!-- Universal Sidebar will be populated here by JavaScript -->\n        \2'
    
    # Replace the sidebar content
    new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    # Only write if content changed
    if new_content != content:
        with open('$file', 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("    - Replaced sidebar HTML")
    else:
        print("    - No sidebar changes needed")
        
except Exception as e:
    print(f"    - Error processing file: {e}")
EOF
}

# Get all HTML files with sidebars
HTML_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/hr/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/recruitment.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/performance-reviews.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/settings.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leads.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/customers.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/payments.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/advanced_reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports_new.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/projects.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/daily-reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/team.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/performance-reviews.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/penalties.html"
)

for file in "${HTML_FILES[@]}"; do
    replace_sidebar_html "$file"
done

echo ""
echo "Sidebar HTML replacement completed!"
echo "All department HTML files now use universal sidebar placeholder."
