#!/bin/bash
# Script to update IST conversion in attendance files

ATTENDANCE_FILE="app/web/departments/development/attendance.html"

echo "Updating IST conversion in $ATTENDANCE_FILE"

# Print current state before modifications
echo "Before update:"
grep -n "convertToIST" "$ATTENDANCE_FILE" | head -3

# Replace the convertToIST function with fixed implementation
sed -i 's|function convertToIST(date) {.*getTimezoneOffset() \* 60000);.*istOffset = 5\.5 \* 60 \* 60 \* 1000;.*return new Date(utcTime + istOffset);.*}|function convertToIST(date) { return new Date(date.getTime() + (5.5 * 60 * 60 * 1000) - (date.getTimezoneOffset() * 60 * 1000)); }|s' "$ATTENDANCE_FILE"

# Print updated state
echo -e "\nAfter update:"
grep -n "convertToIST" "$ATTENDANCE_FILE" | head -3

echo -e "\nIST conversion updated successfully!"

# Create a test file
cat > ist_conversion_test.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>IST Time Conversion Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .result { margin: 10px 0; padding: 10px; background: #f5f5f5; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <h1>IST Time Conversion Test</h1>
    <div id="results"></div>

    <script>
        const results = document.getElementById('results');
        
        // Get current date
        const now = new Date();
        
        // Display function
        function addResult(title, data) {
            const div = document.createElement('div');
            div.className = 'result';
            div.innerHTML = `<h3>${title}</h3>${data}`;
            results.appendChild(div);
        }
        
        // Show local time
        addResult("Local Time", `
            Date: ${now.toDateString()}<br>
            Time: ${now.toTimeString()}<br>
            ISO: ${now.toISOString()}<br>
            Offset: ${now.getTimezoneOffset()} minutes
        `);
        
        // Convert to IST using new method
        function convertToIST(date) {
            return new Date(date.getTime() + (5.5 * 60 * 60 * 1000) - (date.getTimezoneOffset() * 60 * 1000));
        }
        
        const istTime = convertToIST(now);
        
        // Show IST time
        addResult("Indian Standard Time (IST)", `
            Date: ${istTime.toDateString()}<br>
            Time: ${istTime.toTimeString()}<br>
            ISO: ${istTime.toISOString()}<br>
            Local: ${istTime.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}
        `);
        
        // Show calculation steps
        addResult("Calculation Steps", `
            1. Start with local time: ${now.toISOString()}<br>
            2. Local timezone offset: ${now.getTimezoneOffset()} minutes<br>
            3. IST offset: +5 hours 30 minutes (5.5 hours)<br>
            4. Formula: date.getTime() + (5.5 * 60 * 60 * 1000) - (date.getTimezoneOffset() * 60 * 1000)<br>
            5. Result: ${istTime.toISOString()}
        `);
    </script>
</body>
</html>
EOF

echo "Created a test file 'ist_conversion_test.html' to verify IST conversion"
