#!/bin/bash

# Remove sidebar JavaScript handling from Sales department HTML files
# This script will remove menu toggle and sidebar-related JavaScript code

SALES_DIR="/home/ubuntu/test/company_crm/app/web/departments/sales"

# Array of Sales pages to process
SALES_PAGES=(
    "attendance.html"
    "dashboard.html"
    "leads.html"
    "customers.html"
    "payments.html"
    "reports.html"
    "advanced_reports.html"
    "reports_new.html"
    "leave-requests.html"
    "profile.html"
)

echo "Removing sidebar JavaScript handling from Sales department HTML files..."

for page in "${SALES_PAGES[@]}"; do
    file_path="$SALES_DIR/$page"
    
    if [ -f "$file_path" ]; then
        echo "Processing $page..."
        
        # Create backup
        cp "$file_path" "$file_path.bak"
        
        # Remove menu toggle event listeners (multiple patterns)
        sed -i '/document\.getElementById(.*menuToggle.*addEventListener/,+2d' "$file_path"
        sed -i '/const menuToggle = document\.getElementById/,+6d' "$file_path"
        sed -i '/\.querySelector.*sidebar.*classList\.toggle/d' "$file_path"
        
        # Remove user dropdown toggle functionality
        sed -i '/userDropdown.*classList\.toggle/d' "$file_path"
        
        # Remove setupEventListeners function calls for sidebar
        sed -i '/setupEventListeners();/d' "$file_path"
        
        # Remove function definitions that handle sidebar toggle
        sed -i '/function setupEventListeners/,/^[[:space:]]*}[[:space:]]*$/d' "$file_path"
        
        echo "  ✓ Removed sidebar JavaScript handling from $page"
        
    else
        echo "  ✗ File not found: $file_path"
    fi
done

echo ""
echo "Sidebar JavaScript handling removal completed!"
echo "Backup files created with .bak extension"
echo ""
echo "Removed components:"
echo "  - Menu toggle event listeners"
echo "  - Sidebar classList.toggle functionality"
echo "  - User dropdown toggle functionality"
echo "  - setupEventListeners function calls"
echo "  - setupEventListeners function definitions"
