#!/bin/bash

# Comprehensive script to update all department HTML files with universal sidebar

echo "Starting comprehensive update of all department HTML files..."

# Function to update HTML files
update_html_file() {
    local file="$1"
    local dept="$2"
    
    if [ ! -f "$file" ]; then
        echo "  - File not found: $file"
        return
    fi
    
    echo "  Processing: $file"
    
    # Step 1: Add universal-sidebar.js script if not already present
    if ! grep -q "universal-sidebar.js" "$file"; then
        # Try different script inclusion patterns based on department
        if grep -q "hr-utils.js" "$file"; then
            sed -i 's|<script src="/static/js/hr-utils.js[^"]*"></script>|&\n    <script src="/static/js/universal-sidebar.js?v=1"></script>|g' "$file"
            echo "    - Added universal-sidebar.js (HR utils pattern)"
        elif grep -q "sales-utils.js" "$file"; then
            sed -i 's|<script src="/static/js/sales-utils.js[^"]*"></script>|&\n    <script src="/static/js/universal-sidebar.js?v=1"></script>|g' "$file"
            echo "    - Added universal-sidebar.js (Sales utils pattern)"
        elif grep -q "dev-utils.js" "$file"; then
            sed -i 's|<script src="/static/js/dev-utils.js[^"]*"></script>|&\n    <script src="/static/js/universal-sidebar.js?v=1"></script>|g' "$file"
            echo "    - Added universal-sidebar.js (Dev utils pattern)"
        elif grep -q "</head>" "$file"; then
            sed -i 's|</head>|    <script src="/static/js/universal-sidebar.js?v=1"></script>\n</head>|g' "$file"
            echo "    - Added universal-sidebar.js (head pattern)"
        fi
    fi
    
    # Step 2: Add universal sidebar initialization to existing initialization code
    if grep -q "initializeHRPage" "$file" && ! grep -q "universalSidebar.manualInit" "$file"; then
        sed -i '/initializeHRPage();/a\\n                // Initialize universal sidebar with user data\n                if (window.universalSidebar && currentUser) {\n                    window.universalSidebar.manualInit(currentUser);\n                }' "$file"
        echo "    - Added HR sidebar initialization"
    elif grep -q "initializeSalesPage" "$file" && ! grep -q "universalSidebar.manualInit" "$file"; then
        sed -i '/initializeSalesPage();/a\\n                // Initialize universal sidebar with user data\n                if (window.universalSidebar && currentUser) {\n                    window.universalSidebar.manualInit(currentUser);\n                }' "$file"
        echo "    - Added Sales sidebar initialization"
    elif grep -q "initializeDevPage" "$file" && ! grep -q "universalSidebar.manualInit" "$file"; then
        sed -i '/initializeDevPage();/a\\n                // Initialize universal sidebar with user data\n                if (window.universalSidebar && currentUser) {\n                    window.universalSidebar.manualInit(currentUser);\n                }' "$file"
        echo "    - Added Dev sidebar initialization"
    fi
    
    echo "    - Completed: $file"
}

# HR Department Files
echo "Updating HR Department files..."
HR_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/hr/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/recruitment.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/performance-reviews.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/hr/settings.html"
)

for file in "${HR_FILES[@]}"; do
    update_html_file "$file" "hr"
done

# Sales Department Files
echo "Updating Sales Department files..."
SALES_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/sales/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leads.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/customers.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/payments.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/advanced_reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/sales/reports_new.html"
)

for file in "${SALES_FILES[@]}"; do
    update_html_file "$file" "sales"
done

# Development Department Files
echo "Updating Development Department files..."
DEV_FILES=(
    "/home/ubuntu/test/company_crm/app/web/departments/development/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/projects.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/daily-reports.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/team.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/performance-reviews.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/profile.html"
    "/home/ubuntu/test/company_crm/app/web/departments/development/penalties.html"
)

for file in "${DEV_FILES[@]}"; do
    update_html_file "$file" "development"
done

# Shared Files
echo "Updating Shared files..."
SHARED_FILES=(
    "/home/ubuntu/test/company_crm/app/web/shared/attendance.html"
    "/home/ubuntu/test/company_crm/app/web/shared/leave-requests.html"
    "/home/ubuntu/test/company_crm/app/web/shared/performance-reviews.html"
)

for file in "${SHARED_FILES[@]}"; do
    update_html_file "$file" "shared"
done

# Top-level files
echo "Updating top-level files..."
TOP_LEVEL_FILES=(
    "/home/ubuntu/test/company_crm/app/web/dashboard.html"
    "/home/ubuntu/test/company_crm/app/web/projects.html"
    "/home/ubuntu/test/company_crm/app/web/teams.html"
    "/home/ubuntu/test/company_crm/app/web/settings.html"
)

for file in "${TOP_LEVEL_FILES[@]}"; do
    update_html_file "$file" "general"
done

echo ""
echo "Universal sidebar update completed for all department HTML files!"
echo "Summary:"
echo "- Updated HR department files"
echo "- Updated Sales department files" 
echo "- Updated Development department files"
echo "- Updated Shared files"
echo "- Updated Top-level files"
echo ""
echo "All files now include universal-sidebar.js and initialization code."
