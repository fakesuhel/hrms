#!/usr/bin/env python3
import asyncio
import sys
import os
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext

# Initialize password context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

async def create_test_users():
    """Create comprehensive test users for all roles and departments"""
    client = AsyncIOMotorClient('mongodb+srv://test:test123@cluster0.g3zdcff.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    db = client.bhoomi_techzone_hrms
    users_collection = db.users
    
    # Test users with different roles and departments
    test_users = [
        # Admin users
        {
            'username': 'admin',
            'email': 'admin@company.com',
            'full_name': 'System Administrator',
            'password': hash_password('admin123'),
            'role': 'admin',
            'department': 'Management',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'director',
            'email': 'director@company.com',
            'full_name': 'Company Director',
            'password': hash_password('director123'),
            'role': 'director',
            'department': 'Management',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'ceo',
            'email': 'ceo@company.com',
            'full_name': 'Chief Executive Officer',
            'password': hash_password('ceo123'),
            'role': 'ceo',
            'department': 'Management',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        
        # Sales Department
        {
            'username': 'sales_manager',
            'email': 'sales.manager@company.com',
            'full_name': 'Sales Manager',
            'password': hash_password('sales123'),
            'role': 'sales_manager',
            'department': 'Sales',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'sales_lead',
            'email': 'sales.lead@company.com',
            'full_name': 'Sales Team Lead',
            'password': hash_password(''),
            'role': 'team_lead',
            'department': 'Sales',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'sales_emp',
            'email': 'sales.emp@company.com',
            'full_name': 'Sales Employee',
            'password': hash_password('sales123'),
            'role': 'employee',
            'department': 'Sales',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        
        # HR Department
        {
            'username': 'hr_manager',
            'email': 'hr.manager@company.com',
            'full_name': 'HR Manager',
            'password': hash_password('hr123'),
            'role': 'manager',
            'department': 'Human Resources',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'hr_lead',
            'email': 'hr.lead@company.com',
            'full_name': 'HR Team Lead',
            'password': hash_password('hr123'),
            'role': 'team_lead',
            'department': 'Human Resources',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'hr_emp',
            'email': 'hr.emp@company.com',
            'full_name': 'HR Employee',
            'password': hash_password('hr123'),
            'role': 'employee',
            'department': 'Human Resources',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        
        # Development Department
        {
            'username': 'dev_manager',
            'email': 'dev.manager@company.com',
            'full_name': 'Development Manager',
            'password': hash_password('dev123'),
            'role': 'dev_manager',
            'department': 'Development',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'dev_lead',
            'email': 'dev.lead@company.com',
            'full_name': 'Development Team Lead',
            'password': hash_password('dev123'),
            'role': 'team_leader',
            'department': 'Development',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'developer',
            'email': 'developer@company.com',
            'full_name': 'Software Developer',
            'password': hash_password('dev123'),
            'role': 'employee',
            'department': 'Development',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        
        # Marketing Department
        {
            'username': 'marketing_manager',
            'email': 'marketing.manager@company.com',
            'full_name': 'Marketing Manager',
            'password': hash_password('marketing123'),
            'role': 'manager',
            'department': 'Marketing',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'marketing_emp',
            'email': 'marketing.emp@company.com',
            'full_name': 'Marketing Employee',
            'password': hash_password('marketing123'),
            'role': 'employee',
            'department': 'Marketing',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        
        # Finance Department
        {
            'username': 'finance_manager',
            'email': 'finance.manager@company.com',
            'full_name': 'Finance Manager',
            'password': hash_password('finance123'),
            'role': 'manager',
            'department': 'Finance',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        },
        {
            'username': 'accountant',
            'email': 'accountant@company.com',
            'full_name': 'Accountant',
            'password': hash_password('finance123'),
            'role': 'employee',
            'department': 'Finance',
            'is_active': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
    ]
    
    print(f"Creating {len(test_users)} test users...")
    
    # Check if users already exist and create only new ones
    created_count = 0
    for user in test_users:
        existing = await users_collection.find_one({'username': user['username']})
        if not existing:
            result = await users_collection.insert_one(user)
            print(f'✓ Created user: {user["username"]} - {user["role"]} in {user["department"]}')
            created_count += 1
        else:
            print(f'- User already exists: {user["username"]}')
    
    print(f'\n=== Summary ===')
    print(f'Total users created: {created_count}')
    print(f'Total users checked: {len(test_users)}')
    
    # Show all users in database
    all_users = await users_collection.find({}, {'password': 0}).to_list(length=None)
    print(f'\n=== All Users in Database ===')
    for user in all_users:
        print(f'{user.get("username", "N/A")} | {user.get("role", "N/A")} | {user.get("department", "N/A")}')
    
    client.close()

if __name__ == "__main__":
    asyncio.run(create_test_users())
