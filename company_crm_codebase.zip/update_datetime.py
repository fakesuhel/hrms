#!/usr/bin/env python3
import os
import re

def update_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Replace date.today() with get_ist_date_today()
    content = re.sub(r'date\.today\(\)', 'get_ist_date_today()', content)
    
    # Replace datetime.now() with get_ist_now()
    content = re.sub(r'datetime\.now\(\)', 'get_ist_now()', content)
    
    # Replace datetime.utcnow() with get_ist_now()
    content = re.sub(r'datetime\.utcnow\(\)', 'get_ist_now()', content)
    
    with open(file_path, 'w') as f:
        f.write(content)
    
    print(f"Updated {file_path}")

def process_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                update_file(file_path)

# Update all Python files in routes and database directories
process_directory('/home/ubuntu/test/company_crm/app/routes')
process_directory('/home/ubuntu/test/company_crm/app/database')

print("Datetime usage updated in all files.")
