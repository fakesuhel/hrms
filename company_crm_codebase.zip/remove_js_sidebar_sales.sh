#!/bin/bash

# Remove automatic JavaScript sidebar loading from all Sales HTML files
# This script will remove initializeNavigation function calls and definitions

SALES_DIR="/home/ubuntu/test/company_crm/app/web/departments/sales"

# Array of Sales pages to process
SALES_PAGES=(
    "attendance.html"
    "customers.html"
    "payments.html"
    "reports.html"
    "advanced_reports.html"
    "reports_new.html"
    "leave-requests.html"
    "profile.html"
)

echo "Removing automatic JavaScript sidebar loading from Sales HTML files..."

for page in "${SALES_PAGES[@]}"; do
    file_path="$SALES_DIR/$page"
    
    if [ -f "$file_path" ]; then
        echo "Processing $page..."
        
        # Create backup
        cp "$file_path" "$file_path.js_sidebar_bak"
        
        # Remove initializeNavigation() function calls
        sed -i '/initializeNavigation();/d' "$file_path"
        
        # Remove initializeNavigation function definition (multi-line)
        sed -i '/function initializeNavigation/,/^[[:space:]]*}[[:space:]]*$/d' "$file_path"
        
        # Remove role-aware.js script includes
        sed -i '/<script src="\/static\/js\/role-aware\.js"><\/script>/d' "$file_path"
        
        # Remove any remaining sidebar initialization patterns
        sed -i '/window\.universalSidebar/d' "$file_path"
        sed -i '/UniversalSidebar/d' "$file_path"
        
        echo "  ✓ Removed automatic sidebar JavaScript from $page"
        
    else
        echo "  ✗ File not found: $file_path"
    fi
done

echo ""
echo "Automatic JavaScript sidebar loading removal completed!"
echo "Backup files created with .js_sidebar_bak extension"
echo ""
echo "Removed components:"
echo "  - initializeNavigation() function calls"
echo "  - initializeNavigation() function definitions"
echo "  - role-aware.js script includes"
echo "  - Universal sidebar references"
