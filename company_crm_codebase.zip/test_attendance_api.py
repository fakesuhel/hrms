#!/usr/bin/env python3
"""Test attendance API with proper authentication"""

import requests
import json

# Server URL
BASE_URL = "http://127.0.0.1:5448"

def test_attendance_api():
    print("Testing attendance API with authentication...")
    
    # Test credentials - we'll need to update a user to HR role first
    login_data = {
        "username": "admin",  # Adjust based on actual user
        "password": "admin123"  # Adjust based on actual password
    }
    
    try:
        # Try to login
        print("1. Attempting login...")
        login_response = requests.post(
            f"{BASE_URL}/api/users/token", 
            data={"username": login_data["username"], "password": login_data["password"]}
        )
        print(f"Login status: {login_response.status_code}")
        
        if login_response.status_code == 200:
            login_result = login_response.json()
            token = login_result.get("access_token")
            
            if token:
                print(f"Login successful! Token: {token[:20]}...")
                
                # Test attendance API
                print("2. Testing attendance API...")
                headers = {"Authorization": f"Bearer {token}"}
                attendance_response = requests.get(
                    f"{BASE_URL}/api/hr/attendance?month=8&year=2025",
                    headers=headers
                )
                
                print(f"Attendance API status: {attendance_response.status_code}")
                
                if attendance_response.status_code == 200:
                    attendance_data = attendance_response.json()
                    print(f"Attendance records found: {len(attendance_data)}")
                    
                    if attendance_data:
                        print("Sample record:")
                        print(json.dumps(attendance_data[0], indent=2))
                else:
                    print(f"Attendance API error: {attendance_response.text}")
            else:
                print("No token received in login response")
                print(f"Login response: {login_response.text}")
        else:
            print(f"Login failed: {login_response.text}")
            
    except Exception as e:
        print(f"Error during test: {e}")

def check_hr_users():
    """Check if we have any HR users"""
    import sys
    import os
    sys.path.append('/home/ubuntu/test/company_crm')
    
    from app.database.users import users_collection
    
    print("Checking for HR users...")
    hr_users = list(users_collection.find({
        "role": {"$in": ["director", "hr", "manager"]},
        "is_active": True
    }))
    
    print(f"HR users found: {len(hr_users)}")
    for user in hr_users:
        print(f"- {user.get('username', 'N/A')} ({user.get('role', 'N/A')})")
    
    if not hr_users:
        print("No HR users found. Creating one...")
        # Get first active user
        user = users_collection.find_one({"is_active": True})
        if user:
            result = users_collection.update_one(
                {"_id": user["_id"]},
                {"$set": {"role": "hr"}}
            )
            print(f"Updated user {user.get('username', 'N/A')} to HR role")
            return user.get('username'), 'admin123'  # Default password
    else:
        return hr_users[0].get('username'), 'admin123'  # Default password

if __name__ == "__main__":
    # First check/create HR users
    username, password = check_hr_users()
    
    # Update login data
    login_data = {"username": username, "password": password}
    
    # Test the API
    test_attendance_api()
