#!/bin/bash

# Fix Sales pages sidebar initialization
# This script will standardize the sidebar initialization across all Sales pages

# Define the sales pages directory
SALES_DIR="/home/ubuntu/test/company_crm/app/web/departments/sales"

# Array of Sales pages to fix
SALES_PAGES=(
    "attendance.html"
    "leads.html" 
    "customers.html"
    "payments.html"
    "reports.html"
    "advanced_reports.html"
    "reports_new.html"
    "leave-requests.html"
    "profile.html"
)

# Standard sidebar initialization code (based on working dashboard pattern)
SIDEBAR_INIT_CODE='
            // Initialize universal sidebar
            if (window.currentUser && window.universalSidebar) {
                window.universalSidebar.manualInit(window.currentUser);
            }'

echo "Fixing Sales pages sidebar initialization..."

for page in "${SALES_PAGES[@]}"; do
    file_path="$SALES_DIR/$page"
    
    if [ -f "$file_path" ]; then
        echo "Processing $page..."
        
        # Create backup
        cp "$file_path" "$file_path.bak"
        
        # Remove existing sidebar initialization patterns
        sed -i '/window\.universalSidebar\.manualInit/d' "$file_path"
        sed -i '/setTimeout.*universalSidebar/,+10d' "$file_path"
        
        # Find the loadCurrentUser() call and add sidebar init after it
        # This pattern should work for most pages
        if grep -q "await loadCurrentUser();" "$file_path"; then
            sed -i '/await loadCurrentUser();/a\\n            // Initialize universal sidebar\n            if (window.currentUser && window.universalSidebar) {\n                window.universalSidebar.manualInit(window.currentUser);\n            }' "$file_path"
            echo "  ✓ Added sidebar initialization after loadCurrentUser() in $page"
        elif grep -q "loadCurrentUser();" "$file_path"; then
            sed -i '/loadCurrentUser();/a\\n            // Initialize universal sidebar\n            if (window.currentUser && window.universalSidebar) {\n                window.universalSidebar.manualInit(window.currentUser);\n            }' "$file_path"
            echo "  ✓ Added sidebar initialization after loadCurrentUser() in $page"
        else
            echo "  ⚠ Could not find loadCurrentUser() call in $page - manual fix needed"
        fi
        
    else
        echo "  ✗ File not found: $file_path"
    fi
done

echo "Sales pages sidebar initialization fix completed!"
echo "Backup files created with .bak extension"
