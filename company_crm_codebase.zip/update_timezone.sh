#!/bin/bash
# Script to update timezone to IST in all database files

# Files to update
files=(
    "app/database/users.py"
    "app/database/attendance.py" 
    "app/database/leads.py"
    "app/database/customers.py"
    "app/database/projects.py"
    "app/database/documents.py"
    "app/database/hr_policies.py"
    "app/database/salary_slips.py"
    "app/database/recruitment.py"
    "app/utils/auth.py"
)

# Add IST timezone imports and helper function to each file
for file in "${files[@]}"; do
    echo "Updating $file..."
    
    # Check if file exists
    if [ ! -f "$file" ]; then
        echo "File $file not found, skipping..."
        continue
    fi
    
    # Add timezone import if not present
    if ! grep -q "from datetime import.*timezone" "$file"; then
        sed -i 's/from datetime import \([^,]*\)$/from datetime import \1, timezone/' "$file"
    fi
    
    # Add IST timezone definition after imports (before first class/function)
    if ! grep -q "IST = timezone" "$file"; then
        # Find line number of first class or function definition
        line_num=$(grep -n "^class\|^def\|^async def" "$file" | head -1 | cut -d: -f1)
        if [ -n "$line_num" ]; then
            # Insert IST definition before first class/function
            sed -i "${line_num}i\\
\\
# IST timezone (UTC+5:30)\\
IST = timezone(timedelta(hours=5, minutes=30))\\
\\
def get_ist_now():\\
    \"\"\"Get current datetime in IST timezone\"\"\"\\
    return datetime.now()\\
" "$file"
        fi
    fi
    
    # Replace datetime.now() with get_ist_now()
    sed -i 's/datetime\.now()/get_ist_now()/g' "$file"
    
    echo "Updated $file"
done

echo "All files updated with IST timezone support!"
